import airbnbBase from 'eslint-config-airbnb-base';

export default [
  {
    ...airbnbBase[0],
    files: ['**/*.js'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: {
        window: 'readonly',
        document: 'readonly',
        google: 'readonly'
      }
    }
  }
];
