const foo = 42
console.log(foo)
